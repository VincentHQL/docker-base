#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os.path

from tornado.template import BaseLoader, Template


class MultiRootLoader(BaseLoader):

    def __init__(self, roots, **kwargs):
        super(MultiRootLoader, self).__init__(**kwargs)
        if isinstance(roots, str):
            self.roots = [roots]
        else:
            assert isinstance(roots, (list, tuple)), "roots should be lists"
            self.roots = roots

    def resolve_path(self, name, parent_path=None):
        return name

    def _create_template(self, name):
        path = self._detect_template_path(name)
        with open(path, 'r') as f:
            template = Template(f.read(), name=name, loader=self)
            return template

    def _detect_template_path(self, name):
        for root in self.roots:
            path = os.path.join(root, name)
            if os.path.exists(path):
                return path

        return name
