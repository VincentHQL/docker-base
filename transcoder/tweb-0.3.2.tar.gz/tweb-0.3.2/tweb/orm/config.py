#!/usr/bin/env python
# -*- coding: utf-8 -*-

DEBUG = False

db_by_table = None

