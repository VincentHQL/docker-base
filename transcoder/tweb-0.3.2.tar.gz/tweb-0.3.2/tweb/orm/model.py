#!/usr/bin/env python
# -*- coding: utf-8 -*-

from tweb.util import safestr, safeunicode

from .config import db_by_table
from .query import Query, itemgetter0


# _Model {{{
class _Model(type):
    def __new__(cls, name, bases, attrs):
        base0 = bases[0]
        if base0 is object:
            return super(_Model, cls).__new__(cls, name, bases, attrs)

        new_class = type.__new__(cls, name, bases, attrs)

        new_class.__table__ = table = attrs.get('__table__', name)
        db_by_table_pfn = attrs.get('__db_by_table__', db_by_table)
        new_class.__db__ = db = db_by_table_pfn(table)

        if table is not None:
            cursor = db._cursor()
            try:
                cursor.execute('SELECT * FROM %s LIMIT 1' % table, ())
                new_class.__column__ = map(itemgetter0, cursor.description)
            finally:
                cursor.close()

        return new_class
# }}}


# Model {{{
class Model(object):
    __metaclass__ = _Model

    def __init__(self, **kwargs):
        self.__dict__['id'] = None
        self._is_new = True
        for k, v in kwargs.iteritems():
            self.__dict__[k] = v
        self.__dict__['_updated'] = set()

    def __setattr__(self, name, value):
        dc = self.__dict__
        if name[0] != '_' and name in self.__column__:
            if self._is_new:
                dc[name] = value
                return
            dc_value = dc[name]
            if dc_value is None:
                self._updated.add(name)
            else:
                if value is not None:
                    if isinstance(dc_value, unicode):
                        value = safeunicode(value)
                    elif isinstance(dc_value, str):
                        value = safestr(value)
                    else:
                        value = type(dc_value)(value)
                if dc_value != value:
                    self._updated.add(name)
            dc[name] = value
        else:
            attr = getattr(self.__class__, name, None)
            if attr and hasattr(attr, 'fset'):
                attr.fset(self, value)
            else:
                dc[name] = value

    def __ne__(self, other):
        return not (self == other)

    def __eq__(self, other):
        if other is not None:
            sid = self.id
            oid = other.id
            if sid is not None and oid is not None:
                return sid == oid
        return False

    def to_dict(self, fields=None):
        out = {}
        keys = fields or self.__column__
        for k in keys:
            out[k] = getattr(self, k, None)
        return out

    @classmethod
    def get(cls, id=None, **kwargs):
        if id is None:
            if not kwargs:
                return
        else:
            kwargs = {
                'id': id
            }
        q = Query(model=cls, conditions=kwargs)
        q.limit = (0, 1)
        rows = q._db_query()
        if rows:
            row = rows[0]
            obj = cls(**row)
            obj.__dict__['_is_new'] = False
            return obj

    @classmethod
    def get_or_create(cls, **kwargs):
        ins = cls.get(**kwargs)
        if ins is None:
            ins = cls(**kwargs)
        return ins

    def save(self):
        if self._is_new:
            self._insert()
            self._is_new = False
        elif self._updated:
            self._update()
        self._updated.clear()
        return self

    def delete(self):
        self.__db__.execute(
            'DELETE FROM %s WHERE id=%%s' % self.__table__,
            self.id
        )

    @classmethod
    def where(cls, *args, **kwargs):
        return Query(
            model=cls,
            args=args,
            conditions=kwargs
        )

    @classmethod
    def count(cls, *args, **kwargs):
        return Query(
            model=cls,
            args=args,
            conditions=kwargs
        ).count(1)

    @classmethod
    def iter(cls, id=0, where=None, limit=500):
        while True:
            if where:
                r = cls.where(where)
            else:
                r = cls

            r = r.where('id>%s', id).order_by('id')
            total = tuple(r[:limit])
            if total:
                for i in total:
                    yield i
                id = total[-1].id
            else:
                break

    @classmethod
    def max_id(cls):
        sql = 'SELECT MAX(id) AS max_id FROM %s' % cls.__table__
        max_id = cls.__db__.get(sql)['max_id']
        return max_id

    def _insert(self):
        id = self.id
        col_names = [f for f in self.__column__ if id is not None or f != 'id']

        fields = []
        values = []
        for k in col_names:
            v = getattr(self, k, None)
            if v is not None:
                fields.append('`%s`' % k)
                values.append(v)

        query = 'INSERT INTO %s (%s) VALUES (%s)' % (
               self.__table__,
               ','.join(fields),
               ','.join(['%s'] * len(fields) )
        )
        last_id = self.__db__.insert(query, *values)

        if id is None:
            self.id = last_id

    def _update(self):
        query = [
            'UPDATE %s SET ' % self.__table__,
            ','.join(['`%s`=%%s' % f for f in self._updated]),
            ' WHERE id=%s '
        ]

        values = [getattr(self, f) for f in self._updated]
        values.append(self.id)

        self.__db__.update(' '.join(query), *values)
# }}}

