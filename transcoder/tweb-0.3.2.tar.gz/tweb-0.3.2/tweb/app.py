#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os.path

from tornado.web import Application, URLSpec
from tornado.util import import_object

from .template import MultiRootLoader
from .util import get_root_path, storage

__all__ = ["Blueprint", "Tweb"]


class Blueprint(object):
    _first_register = True

    def __init__(self, name, import_name, template_folder=None,
                 handlers=None, ui_modules=None, **settings):
        self.name = name
        self.import_name = import_name
        self.handlers = handlers
        self.ui_modules = ui_modules
        self.settings = settings
        self.root_path = get_root_path(self.import_name)

        if template_folder:
            self.template_path = os.path.join(self.root_path, template_folder)
        else:
            self.template_path = None

    def add_handler(self, handler):
        if self.handlers is None:
            self.handlers = [handler]
        else:
            self.handlers.append(handler)

    def first_register(self):
        if not self._first_register:
            return False
        print("Register: %s" % self.name)
        self._first_register = False
        return True


class Tweb(object):

    def __init__(self, handlers=None, default_host="", transforms=None,
                 **settings):
        self.handlers = handlers
        self.default_host = default_host
        self.transforms = transforms

        if 'template_path' in settings:
            template_path = settings.pop('template_path')
            if isinstance(template_path, str):
                settings['template_path'] = [template_path]
        else:
            settings['template_path'] = []

        self.settings = settings

    def add_handler(self, handler):
        if not self.handlers:
            self.handlers = []

        self.handlers.append(handler)

    def add_ui_moudle(self, ui_module):
        if 'ui_modules' not in self.settings:
            self.settings['ui_modules'] = {}

        if ui_module:
            self.settings['ui_modules'].update(ui_module)

    def register_filter(self, name, func):
        if '__tweb_filters__' not in self.settings:
            self.settings['__tweb_filters__'] = {}

        self.settings['__tweb_filters__'].update({name: func})

    def register_context(self, key, value):
        if '__tweb_global__' not in self.settings:
            self.settings['__tweb_global__'] = storage()

        self.settings['__tweb_global__'][key] = value

    def register_blueprint(self, bp, url_prefix=''):
        if isinstance(bp, str):
            bp = import_object(bp)
        if bp.first_register():
            self._register_bp_handlers(bp, url_prefix)
            self._register_bp_ui_modules(bp)

            if bp.template_path:
                self.settings['template_path'].append(bp.template_path)

    def _register_bp_handlers(self, bp, url_prefix):
        if not bp.handlers:
            return
        for spec in bp.handlers:
            if isinstance(spec, tuple):
                assert len(spec) in (2, 3)
                pattern = spec[0]
                handler = spec[1]

                if isinstance(handler, str):
                    handler = import_object(handler)

                if len(spec) == 3:
                    kwargs = spec[2]
                else:
                    kwargs = {}

                pattern = '%s%s' % (url_prefix, pattern)
                spec = URLSpec(pattern, handler, kwargs)
            elif isinstance(spec, URLSpec):
                pattern = '%s%s' % (url_prefix, spec.regex.pattern)
                spec = URLSpec(pattern, spec.handler_class,
                               spec.kwargs, spec.name)

            self.add_handler(spec)

    def _register_bp_ui_modules(self, bp):
        self.add_ui_moudle(bp.ui_modules)

    def __call__(self):
        kwargs = {}
        if 'autoescape' in self.settings:
            kwargs['autoescape'] = self.settings['autoescape']
        path = self.settings.pop('template_path')
        loader = MultiRootLoader(path, **kwargs)
        self.settings['template_loader'] = loader
        app = Application(
            self.handlers, self.default_host, self.transforms,
            **self.settings
        )
        return app
