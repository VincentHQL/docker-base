#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tornado.web
import tornado.escape
import tornado.options

from tornado.options import define, options
from tornado.escape import json_encode, utf8, to_unicode

__all__ = ["ErrorHandler", "RequestHandler", "ApiHandler", "run_server"]


class ErrorHandler(tornado.web.RequestHandler):
    def prepare(self):
        self.set_status(404)
        raise tornado.web.HTTPError(404)


class RequestHandler(tornado.web.RequestHandler):
    def get_args(self, key, default=None, type=None):
        if type == list:
            if default is None:
                default = []
            return self.get_arguments(key, default)
        value = self.get_argument(key, default)
        if value is not None and type:
            try:
                value = type(value)
            except ValueError:
                value = default
        return value

    def absolute_redirect(self, url, permanent=False, status=None):
        if self._headers_written:
            raise Exception("Cannot redirect after headers have been written")
        if status is None:
            status = 301 if permanent else 302
        else:
            assert isinstance(status, int) and 300 <= status <= 399
        self.set_status(status)
        self.set_header('Location', utf8(url))
        self.finish()

    def reverse_redirect(self, name, *args):
        self.redirect(self.reverse_url(name, *args))

    def render_string(self, template_name, **kwargs):
        #: add application filters
        if '__tweb_filters__' in self.settings:
            kwargs.update(self.settings['__tweb_filters__'])

        #: add application global variables
        if '__tweb_global__' in self.settings:
            assert "g" not in kwargs, "g is a reserved keyword."
            kwargs["g"] = self.settings['__tweb_global__']

        return super(RequestHandler, self).render_string(template_name, **kwargs)


class ApiHandler(RequestHandler):
    xsrf_protect = False

    def check_xsrf_cookie(self):
        if not self.xsrf_protect:
            return
        return super(ApiHandler, self).check_xsrf_cookie()

    def is_ajax(self):
        return 'XMLHttpRequest' == self.request.headers.get('X-Requested-With')


def run_server(app, address='', port=0):
    import logging
    from tornado import httpserver, ioloop

    tornado.options.parse_command_line()

    server = httpserver.HTTPServer(app(), xheaders=True)
    if(address != '' and port !=0) :
        options.port = port
        options.address = address 
    server.listen(int(options.port), options.address)

    logging.info('Start server at %s:%s' % (options.address, options.port))
    ioloop.IOLoop.instance().start()


define('address', default='127.0.0.1', type=str,
       help='run server at this address')
define('port', default=8000, type=int,
       help='run server on this port')
