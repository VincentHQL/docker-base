#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

import tweb

setup(
    name='tweb',
    version=tweb.__version__,
    description='A simple web framework based on tornado',
    long_description=open('README.rst').read(),
    author=tweb.__author__,
    author_email='hilarryxu@gmail.com',
    url='http://www.hilarryxu.com/p/tweb',
    license='MIT License',
    packages=find_packages(exclude=['tests', 'docs', 'examples']),
    install_requires=[
        'tornado',
    ],
)
